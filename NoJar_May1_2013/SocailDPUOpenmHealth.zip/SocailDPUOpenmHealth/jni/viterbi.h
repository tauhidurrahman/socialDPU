#define LOOK_BACK_LENGTH 20

int getViterbiInference(double *x,double *featureAndInference);
