void rdft(int, int, double *, int *, double *);
void ddct(int, int, double *, int *, double *);
