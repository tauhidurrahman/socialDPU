package edu.cornell.socialdpudemo2;

//import com.simple.gui.R;

import java.util.Timer;
import java.util.TimerTask;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.widget.ImageView;
import android.widget.TextView;
import edu.cornell.SocialDPU.SocialDPUApplication;
import edu.cornell.SocialDPU.ServiceControllers.ServiceController;
import edu.dartmouthcs.mltoolkit.R;


/**
 * This activity is the activity when the app icon gets clicked
 * @author shuva
 *
 */
public class main_activity extends Activity {

	//service controller class for starting and stopping sensor (we only have audio sensor in the SocialDPU)
	private static ServiceController serviceController;
	public static Context context;
	private static Timer audioTimer;// this time periodically update the voice/non-voice inference
	private SocialDPUApplication appState;// reference to application class
	

	private boolean activity_paused;	
	private String prev_audio_status = "Not Available";//status of audio
	
	//update gui stuff
	private ImageView audioImageView;
	private TextView audioTextView;
	private ImageView conversationImageView;
	private TextView conversationTextView;



	private static final String TAG = "ML_Toolkit";
	@Override
	/**
	 * Starts sensors that enabled. In case we have the audio sensor
	 * 
	 */
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		appState = (SocialDPUApplication2)getApplicationContext();
		serviceController = appState.dpuStates.getServiceController();

		Log.i(TAG, "onCreate ...");
		setContentView(R.layout.main);


		//initiate gui elements
		audioTextView = (TextView) findViewById(R.id.button_status_audio);
		audioImageView = (ImageView) findViewById(R.id.status_icon_audio);
		conversationTextView = (TextView) findViewById(R.id.button_status_conversation);
		conversationImageView = (ImageView) findViewById(R.id.status_icon_conversation);
		
		
		//main activity will never start the sensing servcices twice
		if(appState.dpuStates.applicatin_starated == false){

			//this variable makes sure the same service don't get started twice
			//Technically same service can't be started twice. We want make sure context reference 
			//don't screwed since we can't stop assigning.
			//For exampple, there will can be two MyPhoneStateListener trying to stop the audio sensor together and there
			// is a race condition.
			
			appState.dpuStates.applicatin_starated = true;

			//start the audio service
			if(appState.dpuStates.savedAudioSensorOn == true)
				serviceController.startAudioSensor();


		}

		//activity on or off
		this.activity_paused = true;


	}

	@Override
	public void onStart() {
		super.onStart();
		Log.i(TAG, "onStart ...");
	}


	@Override
	/**
	 * We start a timer to change the status of the audio inference 
	 */
	public void onResume() {
		super.onResume();

		//start a timer to update the gui
		audioTimer = new Timer();
		audioTimer.schedule(new TimerTask() {
			@Override
			public void run() {
				audioTimerMethod();
			}

		}, 0, 250);

		//bindings are online so start reading the values again
		this.activity_paused = false;
	}

	@Override
	/**
	 * Get called whenever the activity is not visible
	 */
	public void onPause() {
		super.onPause();	

		//so stop showing results, so stop the audio timer to update
		audioTimer.cancel();
		this.activity_paused = true;
		Log.i(TAG, "onPause ...");
	}

	@Override
	public void onStop() {
		super.onStop();		
		Log.i(TAG, "onStop ...");
	}

	@Override
	public void onDestroy() {
		super.onDestroy();
		Log.i(TAG, "onDestroy ...");
	}

	@Override
	public void onRestart() {
		super.onDestroy();
		Log.i(TAG, "onRestart ...");
	}


	//this function gets called whenever the timer completes a round
	protected void audioTimerMethod() {
		//this method will run on the timer thread
		this.runOnUiThread(audioTimer_Tick);
	}

	private Runnable audioTimer_Tick = new Runnable() {
		public void run() {

			//if audio sensor is turned off
			if (appState.dpuStates.audioSensorOn == false || activity_paused == true){
				setAudioImage("Not Available");
			}
			//audio sensor is running. We need to show the inference results
			else{
				if(appState.voice_infernce_status==1)
					setAudioImage("Voiced");
				else if(appState.voice_infernce_status==0)
					setAudioImage("Unvoiced");
			}
			
			//set the conversation icon
			if(appState.conversation_infernce_status == 0){
				conversationImageView.setImageResource(R.drawable.quiet_001);
				conversationTextView.setText("No conversation");
			}				
			else{
				conversationImageView.setImageResource(R.drawable.converation);
				conversationTextView.setText("In conversation");
			}
				
		}
		
		
	};
	

	protected void setAudioImage(String inferred_status) {
		// TODO Auto-generated method stub
		if(!this.prev_audio_status.equals(inferred_status)){
			prev_audio_status = inferred_status;

			if(inferred_status.equals("Not Available")){
				this.audioImageView.setImageResource(R.drawable.cross);
				this.audioTextView.setText("Not Available");
			}
			else if(inferred_status.equals("Voiced")){
				this.audioImageView.setImageResource(R.drawable.talking_001);
				this.audioTextView.setText("Voiced");
			}
			else if(inferred_status.equals("Unvoiced")){
				//Log.e(main_activity.class.getName(),""+audioImageView);
				this.audioImageView.setImageResource(R.drawable.noise_001);
				this.audioTextView.setText("Unvoiced");
			}

		}
	}





}