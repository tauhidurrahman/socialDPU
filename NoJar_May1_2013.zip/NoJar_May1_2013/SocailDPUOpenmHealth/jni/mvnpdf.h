double computeMvnPdf(double *x, double *mean, double invCov[][3], double denom);
